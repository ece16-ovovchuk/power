clear all 
clc
%importing file from exel
INPUT_FILE='Input.xlsx';
input=xlsread(INPUT_FILE); % input
TARGET_FILE='Target_output.xlsx';
targetoutput=xlsread(TARGET_FILE); %target output
Trail_file='trail.xlsx';
trail=xlsread(Trail_file); % trail for checking the network


x = (input'); 
t = (targetoutput');   

% Choose a Training Function

trainFcn = 'trainlm';  % Levenberg-Marquardt backpropagation.

% Create a Fitting Network
hiddenLayerSize = 4;
net = feedforwardnet(hiddenLayerSize,trainFcn);
% Setup Division of Data for Training, Validation, Testing
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 15/100;
net.divideParam.testRatio = 15/100;
net.trainParam.max_fail=20;
% Train the Network
%================= Creating for loop ================================
iterations = 75;
for i=0:iterations
    %net = init(net);
    [net,tr] = train(net,x,t);
    i=i+1; 
end

% Test the Network
y = net(x);
e = gsubtract(t,y);
performance = perform(net,t,y);

%================ for loop ends ======================================


%=========TRAIL================
try_trail =trail'; 
new_output=net(try_trail);
predicted=new_output'; 
D='actual.xlsx'; 
future_actual_irridance=xlsread(D); 
difference=predicted-future_actual_irridance; 
