clear all 
clc

%importing file

INPUT_FILE='Input.xlsx';
input=xlsread(INPUT_FILE); % input
TARGET_FILE='Target_output.xlsx';
targetoutput=xlsread(TARGET_FILE); %target output
Trail_file='trail.xlsx';
trail=xlsread(Trail_file);
% trained regression model 
model = fitlm(input,targetoutput); 
%predecting regression model 
future_irridenace= predict(model,trail);

%finding difference 
D='actual.xlsx'; 
future_actual_irridance=xlsread(D);
difference=future_actual_irridance-future_irridenace;


%_______________________ 


